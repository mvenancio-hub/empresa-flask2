from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'chave_secreta_empresa_flask'

def conectar_banco():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="empresa_flask"
    )

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        conexao = conectar_banco()
        cursor = conexao.cursor(dictionary=True)
        
        # Busca o usuário ativo no banco
        sql = "SELECT * FROM usuario WHERE email = %s AND senha = %s AND ativo = 1"
        cursor.execute(sql, (email, senha))
        usuario = cursor.fetchone()

        cursor.close()
        conexao.close()

        if usuario:
            return render_template("bem-vindo.html", nome=usuario["nome"])
        else:
            flash("E-mail ou senha inválidos!")
            return redirect(url_for('login'))

    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)